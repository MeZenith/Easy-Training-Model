# 开发约定 — Easy-Tinking

> 按 `PySide6_AI开发规范.md` 格式编写  
> AI 协作开发时必须遵守此约定

---

## 架构约定

1. **UI 文件** (`ui/`) 中禁止出现以下内容:
   - 文件读写逻辑 (`open()`, `json.load()` 等)
   - 网络请求 (`huggingface_hub`, `requests` 等)
   - 复杂的数据处理（超过 5 行的业务逻辑）
   - 直接调用 `os.makedirs`, `shutil.disk_usage` 等

2. **core/** 中禁止 import 任何 `QWidget`, `QMainWindow`, `QDialog`, `QMessageBox` 等 PySide6 UI 类  
   例外: `QObject, Signal, QProcess` 允许（用于子进程通信）

3. **Worker 进程/线程** 中禁止直接操作 UI 控件，只能通过 Signal 或管道回传数据

4. 新增功能时，优先检查 `utils/` 和 `ui/components/` 中是否已有可复用的组件

---

## 代码约定

1. **所有常量** 必须放在 `core/config.py` 的 `_DEFAULT_CONFIG` 中，禁止在代码中硬编码:
   - 魔法数字 (如: `pct < 90`, `free_gb > 5`)
   - 路径 (如: `"workspace/models"`)
   - 超时时间、阈值、默认值

2. **所有日志** 使用 `logging.getLogger("EasyTinking")`，禁止直接 `print()`

3. **耗时操作** (模型下载、训练、导出、推理) 必须放入 Worker (QThread/QProcess)，禁止在主线程执行

4. **信号命名** 用 camelCase (Qt 风格)，普通函数用 snake_case (Python 风格)

5. **每个 .py 文件** 不超过 300 行，超过就拆分

6. **每个函数** 不超过 50 行，超过就拆分为子函数

7. **新增的 public 类/函数** 必须写 docstring，说明"做什么"和"参数含义"

8. **所有用户可见的字符串** 必须通过 `i18n.t(key)` 获取，禁止硬编码中英文

---

## 异常处理约定

1. **每个 except 块必须记录日志**，级别至少为 `logger.warning()`

2. **不允许** `except: pass` 或 `except Exception: pass`

3. **异常要么处理，要么 raise**，不要吞掉

4. 捕获具体异常类型（如 `except OSError`），不要用裸 `except`

---

## 迭代约定

1. 修改现有代码时，必须保持原有架构分层，不允许"图方便"跨界

2. 发现重复代码时，应该抽取为公共函数/组件，而不是复制粘贴

3. **新增文件时**，必须同步更新 `PROJECT_MAP.md`

4. **新增页面时**，必须在 `locale/zh.json` 和 `locale/en.json` 中添加对应的翻译 key

5. 不确定的设计决策，先问，不要猜测

---

## 7 条铁律

| 编号 | 铁律 | Easy-Tinking 具体检查项 |
|------|------|------------------------|
| 1 | **不跨界** | core/ 不 import QMessageBox；ui/ 方法 <5 行业务逻辑 |
| 2 | **不重复** | 先查 PROJECT_MAP.md；`_load_loras()` 勿在多页面实现 |
| 3 | **不硬编码** | 所有阈值/路径/默认值进 config.py；所有文本进 locale/ |
| 4 | **不阻塞** | 训练/下载/导出/推理 全部进 Worker/子进程 |
| 5 | **不吞异常** | 所有 except 有 logger 记录，无裸 pass |
| 6 | **不膨胀** | 文件 ≤300 行，函数 ≤50 行 |
| 7 | **不猜** | 架构/设计不确定时先确认 |
