# .gitignore 修复说明

> 当前文件: `.gitignore` (33行)

---

## 问题1: `assess/` 被错误忽略

**当前** (第14行):
```
# Design assets - not code
assess/
```

**问题**: `assess/` 目录包含应用运行时必需的文件:
- `assess/nav_icons.py` — 侧边栏图标映射，`ui/app.py:26` 必须导入
- `assess/professional_theme.qss` — 暗色主题样式表，`ui/theme.py` 加载
- `assess/light_theme.qss` — 亮色主题样式表

如果 `assess/` 被 gitignore，新开发者克隆后无法启动，会直接报 `ModuleNotFoundError`。

**修复**: 删除 `assess/` 行（或改为注释）

---

## 问题2: `.git/` 未显式过滤

**当前**: `.gitignore` 中没有 `.git/` 条目

**说明**: Git 确实自动忽略 `.git/` 目录（因为那是仓库自身的元数据目录），不会追踪它。但在 `.gitignore` 中显式声明 `.git/` 是**防御性编程**的好习惯：
- 防止在非 git 目录中意外操作
- 让 `.gitignore` 的意图更加明确
- 某些自动化工具（如 `rsync` 部署脚本）可能读取 `.gitignore` 作为排除列表

**修复**: 新增以下行:
```
# Git repository (explicit, though auto-ignored by git)
.git/
```

---

## 建议的完整 .gitignore 修改

```diff
 # Design assets - not code
-assess/
+# assess/ is now tracked (contains nav_icons.py and theme QSS files)
 
 # IDE
 .vscode/
 .idea/
 
 # OS
 Thumbs.db
 .DS_Store
 
 # Virtual env
 venv/
 .venv/
 env/
 
+# Git repository (explicit, though auto-ignored by git)
+.git/
+
 # Generated output
 *.pdf
 
 # PyInstaller
 *.manifest
```

---

## 额外检查: `assess/` 下还应创建的文件

以下文件在代码中被引用但不存在于仓库中，需要创建并提交:

| 文件 | 被引用位置 | 用途 |
|------|-----------|------|
| `assess/nav_icons.py` | `ui/app.py:26` | 侧边栏图标 QIcon 映射 |
| `assess/professional_theme.qss` | `ui/theme.py` | 暗色主题 QSS 样式 |
| `assess/light_theme.qss` | `ui/theme.py` | 亮色主题 QSS 样式 |

### `assess/nav_icons.py` 最小可运行版本

```python
"""侧边栏导航图标"""

from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication

# 使用内置 Qt 风格图标作为降级方案
ICON_MAP = {}

def _get_icon(key: str):
    """获取图标，优先从资源文件，否则用 Unicode 符号"""
    icons = {
        "model":   "\U0001F4E6",  # 包裹 (也可替换为 QStyle 图标)
        "data":    "\U0001F4CA",  # 图表
        "train":   "\u2699\uFE0F",  # 齿轮
        "export":  "\U0001F4E4",  # 发件箱
        "test":    "\U0001F4AC",  # 对话气泡
        "settings":"\u2699\uFE0F",  # 齿轮
        "logs":    "\U0001F4C4",  # 文档
    }
    # 使用 QStyle 标准图标 (降级方案)
    style = QApplication.style()
    std_icons = {
        "model":   style.standardIcon(style.StandardPixmap.SP_DriveHDDIcon),
        "data":    style.standardIcon(style.StandardPixmap.SP_FileIcon),
        "train":   style.standardIcon(style.StandardPixmap.SP_MediaPlay),
        "export":  style.standardIcon(style.StandardPixmap.SP_DialogSaveButton),
        "test":    style.standardIcon(style.StandardPixmap.SP_MessageBoxQuestion),
        "settings":style.standardIcon(style.StandardPixmap.SP_FileDialogDetailedView),
        "logs":    style.standardIcon(style.StandardPixmap.SP_FileDialogInfoView),
    }
    return std_icons
```
