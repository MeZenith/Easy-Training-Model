# 项目地图 — Easy-Tinking

> 按 `PySide6_AI开发规范.md` 格式编写  
> 每次功能迭代后需同步更新此文件

---

## 项目简介

Easy-Tinking 是一个 Python + PySide6 开发的 **零代码 AI 大模型微调桌面工具**。提供可视化界面完成：模型下载 → 数据集管理 → LoRA 微调训练 → 模型导出 → Ollama 部署 → 对话测试 全流程。

---

## 架构分层规则

| 层 | 目录 | 规则 |
|----|------|------|
| **UI 层** | `ui/` | 只做展示和信号转发，**禁止**写业务逻辑 |
| **业务层** | `core/` | 处理核心逻辑，**禁止** import PySide6 UI 组件 |
| **Worker 层** | `core/*_worker.py` | 耗时任务执行，通过 Signal/子进程管道返回结果 |
| **工具层** | `utils/` | 无状态纯函数，可被任意层调用 |
| **配置** | `core/config.py` | 所有常量、路径、默认值的唯一来源 |
| **多语言** | `locale/` | zh.json / en.json 翻译文件 |
| **资源** | `res/` | 图标、图片等静态资源 |

### 依赖方向（单向）

```
ui/ → core/ → utils/
ui/ → workers → core/ → utils/

禁止: core/ 不能import ui/
禁止: workers 不能import ui/ 中的 Widget
```

---

## 现有模块清单

### ui/ — UI 层

| 文件 | 行数 | 职责 | 公共 API |
|------|------|------|---------|
| `ui/app.py` | 323 | 主窗口、标题栏、侧边栏导航、页面切换、全局异常处理 | `MainWindow`, `global_exception_handler()` |
| `ui/theme.py` | 84 | 暗/亮主题管理器 (单例) | `ThemeManager.instance().apply_theme()` |

#### ui/pages/ — 功能页面

| 文件 | 行数 | 职责 | 对外信号 |
|------|------|------|---------|
| `ui/pages/model_page.py` | 392 | 模型管理：下载/删除/详情 | `model_selected` |
| `ui/pages/data_page.py` | 458 | 数据集管理：CRUD/导入/验证 | `datasets_changed` |
| `ui/pages/train_page.py` | 728 | 训练中心：配置+监控双页面 | `training_started`, `training_finished` |
| `ui/pages/export_page.py` | 481 | 导出+Ollama部署 | `export_finished` |
| `ui/pages/test_page.py` | 384 | 对话测试：流式聊天+性能统计 | — |
| `ui/pages/settings_page.py` | 200 | 系统设置：语言/主题/工作目录/代理 | — |
| `ui/pages/logs_page.py` | 238 | 运行时日志查看器 | — |

#### ui/components/ — 可复用组件

| 文件 | 行数 | 职责 |
|------|------|------|
| `ui/components/loss_chart.py` | 91 | 实时 Loss 曲线图 (pyqtgraph) |
| `ui/components/gpu_monitor.py` | 62 | GPU VRAM 使用率进度条 |
| `ui/components/data_table.py` | 79 | 可编辑数据集表格 |
| `ui/components/progress_bar.py` | 40 | 自定义进度条（未充分使用） |
| `ui/components/model_card.py` | 72 | 模型信息卡片 |

### core/ — 业务逻辑层

| 文件 | 行数 | 职责 | 公共 API |
|------|------|------|---------|
| `core/config.py` | 182 | 应用配置管理（JSON 持久化，线程安全） | `AppConfig.get(key)`, `.set(key,val)`, `.workspace` |
| `core/model_manager.py` | 292 | 模型管理：下载/验证/详情/7个内置预设 | `ModelManager.list_downloaded_models()`, `validate_model()` |
| `core/data_manager.py` | 395 | 数据集 CRUD：导入/导出/验证/身份数据生成 | `DataManager`, `Dataset`, `generate_identity_data()` |
| `core/trainer.py` | 520 | 训练管理：QProcess 子进程或 QThread 两种方式 | `ProcessTrainer`, `TrainWorker`(废弃) |
| `core/train_worker.py` | 365 | 独立训练进程入口（argparse + 纯 PyTorch 循环） | CLI 入口 |
| `core/inferencer.py` | 123 | 推理管理：QProcess 子进程流式推理 | `Inferencer.start()`, `.generate()` |
| `core/infer_worker.py` | 165 | 独立推理进程入口（stdin JSON 通信） | CLI 入口 |
| `core/exporter.py` | 322 | 模型导出：16bit/GGUF/LoRA-only | `Exporter`, `ExportWorker` |
| `core/ollama_deployer.py` | 168 | Ollama 部署：检测/创建/运行 | `OllamaDeployer` |
| `core/error_handler.py` | 115 | 错误分类+友好提示 | `classify_error()`, `friendly_error_message()` |

### utils/ — 工具层

| 文件 | 行数 | 职责 |
|------|------|------|
| `utils/i18n.py` | 104 | Signal 驱动的国际化管理器 (单例) |
| `utils/logger.py` | 43 | 日志系统初始化 + 获取器 |
| `utils/worker.py` | 43 | `BaseWorker` QThread基类 + `WorkerSignals` |
| `utils/gpu_info.py` | 58 | nvidia-smi GPU 信息查询 |
| `utils/system_info.py` | 59 | 系统信息 + 依赖版本查询 |

### tools/ — CLI 工具

| 文件 | 行数 | 用途 |
|------|------|------|
| `tools/convert_hf_to_gguf.py` | 138 | HF格式 → GGUF F16 转换 |
| `tools/quantize_gguf.py` | 60 | GGUF F16 → Q8_0/Q4_K_M 量化 |

---

## 已有的可复用组件

| 组件 | 位置 | 说明 | **别再新建** |
|------|------|------|-------------|
| `BaseWorker` | `utils/worker.py` | QThread 基类，提供 progress/finished/error/log 信号 | 新增 Worker 继承它 |
| `DataTable` | `ui/components/data_table.py` | 可编辑表格控件 | 勿在页面内自建 QTableWidget |
| `ModelCard` | `ui/components/model_card.py` | 模型信息卡片 | 勿在各页面重建 |
| `LossChart` | `ui/components/loss_chart.py` | 实时 Loss 图表 | 勿重复引入 pyqtgraph |
| `GPUMonitor` | `ui/components/gpu_monitor.py` | GPU 显存监控 | 勿重复调用 get_gpu_info |
| `AppConfig.get/set` | `core/config.py` | 统一配置管理 | 勿用 os.environ 或全局变量存配置 |
| `i18n.t(key)` | `utils/i18n.py` | 多语言文本 | 勿硬编码中英文字符串 |

---

## 下一步计划

- [ ] P0: 修复 `assess/nav_icons.py` 缺失导致的启动崩溃
- [ ] P1: 拆分 `core/` 为 services/workers/ 子目录
- [ ] P1: 从 UI 页面中抽离业务逻辑到 service
- [ ] P2: 拆分超大文件 (train_page 728行, trainer 520行 等)
- [ ] P2: 修复 17 处异常吞噬
- [ ] P2: 消除代码重复 (load_loras, formatting_func)
- [ ] P3: 添加单元测试
- [ ] P3: 锁定 requirements.txt 版本
