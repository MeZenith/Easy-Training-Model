# PySide6 桌面应用开发规范（AI 协作版）
> 专为「人类 + AI Agent 协作开发」设计，核心目标：防止代码腐烂，保证长期可维护性

---

## 〇、核心理念：为什么 AI 项目会"腐烂"？

AI 的问题不在于单次代码质量，而在于：

1. **没有全局记忆** → 每次迭代都在"重新发明轮子"，导致重复代码堆积
2. **倾向于"就地修改"** → 哪里有问题就改哪里，不做抽象和重构
3. **上下文窗口有限** → 看不到全貌，容易破坏已有架构约定
4. **喜欢"加代码"不喜欢"改结构"** → 文件越堆越大，职责越来越模糊

所以这份规范的核心策略是：

- 用**「物理隔离」**强制架构边界（AI 跨不了界就不容易乱）
- 用**「项目地图文件」**给 AI 提供全局上下文
- 用**「最小化迭代单元」**防止大范围破坏
- 用**「约定清单」**约束 AI 的行为模式

---

## 一、项目结构 —— 物理隔离是第一道防线

目录结构不是"好看"，而是"物理边界"。把文件放对位置，AI 就不容易把业务逻辑塞进 UI 文件里。

```
my_app/
├── PROJECT_MAP.md          ← 【关键】项目地图，每次让 AI 先读这个
├── CONVENTIONS.md          ← 【关键】约定清单，约束 AI 行为
├── main.py                 ← 入口，只做启动，不超过 30 行
├── src/
│   ├── app.py              ← QApplication 初始化、全局配置
│   ├── windows/            ← 窗口（只有窗口，没有逻辑）
│   │   ├── main_window.py
│   │   └── settings_dialog.py
│   ├── widgets/            ← 可复用的自定义控件
│   │   ├── file_selector.py
│   │   └── progress_panel.py
│   ├── services/           ← 业务逻辑层（所有"干活"的代码在这里）
│   │   ├── data_service.py
│   │   └── export_service.py
│   ├── models/             ← 数据模型（dataclass / data container）
│   │   └── task_model.py
│   ├── workers/            ← 线程任务（所有耗时操作在这里）
│   │   └── background_worker.py
│   ├── config.py           ← 配置管理（路径、常量、默认值）
│   ├── styles/             ← 样式表
│   │   └── theme.qss
│   ├── assets/             ← 图标、图片
│   └── utils/              ← 工具函数（纯函数，无状态）
│       ├── logger.py
│       └── file_helper.py
├── tests/
└── pyproject.toml
```

### 关键原则

- `windows/` 里的文件只负责"展示"和"转发信号"，绝不含业务逻辑
- `services/` 里的文件只负责"处理数据"，绝不 import 任何 PySide6 的 UI 类
- `workers/` 里的文件只负责"耗时任务执行"，通过 Signal 返回结果，绝不碰 UI
- 这三层之间通过 Signal/Slot 和函数调用通信，不允许反向依赖

### 依赖方向（必须单向）

```
windows → services → models
windows → workers → services → models

❌ services 绝对不能 import windows
❌ workers 绝对不能 import windows/widgets
```

---

## 二、PROJECT_MAP.md —— 给 AI 的全局导航

这是防止 AI 迭代时"迷失方向"的关键文件。每次让 AI 做新功能之前，先让它读这个文件。

### PROJECT_MAP.md 示例内容

```markdown
# 项目地图

## 项目简介
这是一个 XXX 桌面应用，使用 Python + PySide6 开发。

## 架构分层规则
- windows/  : UI 层，只做展示和信号转发，禁止写业务逻辑
- services/ : 业务层，处理核心逻辑，禁止 import PySide6 UI 组件
- workers/  : 线程层，耗时任务放这里，通过 Signal 回传结果
- models/   : 数据模型，纯数据容器
- utils/    : 工具函数，无状态纯函数
- config.py : 所有常量、路径、默认配置的唯一来源

## 现有模块清单（每次迭代后更新）

### windows/
- main_window.py     → 主窗口，管理页面切换和菜单
- settings_dialog.py → 设置弹窗

### services/
- data_service.py    → 数据加载/保存，对外暴露 load_data() / save_data()
- export_service.py  → 导出功能，对外暴露 export_to_excel()

### workers/
- background_worker.py → 通用后台任务执行器

### models/
- task_model.py      → Task 数据模型

### utils/
- logger.py          → 日志工具，全局使用 get_logger()
- file_helper.py     → 文件路径处理工具

## 已有的可复用组件
- widgets/file_selector.py  → 文件选择器，别再新建一个
- widgets/progress_panel.py → 进度面板，别再新建一个

## 下一步计划
- [ ] 实现数据导入功能
- [ ] 添加用户设置持久化
```

### 使用方式

1. 每次开发新功能前，把 PROJECT_MAP.md 内容发给 AI
2. 每次功能完成后，让 AI 更新这个文件
3. 这样 AI 就知道"已有什么"，不会重复造轮子

---

## 三、CONVENTIONS.md —— 约束 AI 行为的规则清单

### CONVENTIONS.md 示例内容

```markdown
# 开发约定（AI 必须遵守）

## 架构约定
1. UI 文件（windows/, widgets/）中禁止出现以下内容：
   - 数据库操作
   - 文件读写逻辑
   - 网络请求
   - 复杂的数据处理（超过 5 行的业务逻辑）
2. services/ 中禁止 import 任何 QWidget, QMainWindow, QDialog 等 UI 类
3. workers/ 中禁止直接操作 UI 控件，只能通过 Signal 回传数据
4. 新增功能时，优先检查 utils/ 和 widgets/ 中是否已有可复用的组件

## 代码约定
1. 所有常量必须放在 config.py 中，禁止在代码中硬编码魔法数字和路径
2. 所有日志使用 utils/logger.py 的 get_logger()，禁止直接 print()
3. 耗时操作（文件IO、网络、大量计算）必须放入 workers/，禁止在主线程执行
4. 信号命名用 camelCase（Qt 风格），普通函数用 snake_case（Python 风格）
5. 每个 .py 文件不超过 300 行，超过就拆分
6. 每个函数不超过 50 行，超过就拆分
7. 新增的类/函数必须写 docstring，说明"做什么"和"参数含义"

## 迭代约定
1. 修改现有代码时，必须保持原有架构分层，不允许"图方便"跨界
2. 发现重复代码时，应该抽取为公共函数/组件，而不是复制粘贴
3. 新增文件时，必须同步更新 PROJECT_MAP.md
4. 不确定的东西，先问，不要猜着写
```

---

## 四、AI 协作的工作流程 —— 防止"改着改着就废了"

### 4.1 每次开发新功能时的标准流程

**Step 1: 给 AI 提供上下文**

> "请先阅读 PROJECT_MAP.md 和 CONVENTIONS.md，然后帮我实现 XXX 功能"

**Step 2: 让 AI 先出方案，不要直接写代码**

> "不要直接写代码，先告诉我你打算在哪个目录新建什么文件，修改哪些现有文件，各文件的职责是什么"

**Step 3: 人类审核方案**

检查：
- 是否遵守了分层规则？
- 是否重复造了已有组件？
- 文件会不会太大需要提前拆分？

**Step 4: 确认后再让 AI 写代码**

> "方案没问题，开始实现吧"

**Step 5: 完成后让 AI 更新地图**

> "功能完成了，请更新 PROJECT_MAP.md"

### 4.2 每次修改 Bug 时的标准流程

**Step 1: 定位问题**

> "这个 bug 在 XXX 功能中，请先阅读相关文件，分析原因"

**Step 2: 让 AI 说明修复方案**

> "你打算怎么修？修改哪些文件？会不会影响其他功能？"

**Step 3: 关键检查 —— 这是不是一个"补丁式修复"？**

如果 AI 说"我在 XXX 函数里加一个 if 判断"，要追问："这个问题的根本原因是什么？是不是设计上有缺陷？" 避免 bug 修复变成打补丁，补丁越打越烂。

**Step 4: 修复后验证**

让 AI 确认：修改是否影响了其他调用同一模块的地方？

### 4.3 定期"技术债清理"（每完成 3-5 个功能做一次）

> "请阅读以下文件，找出：
> 1. 重复的代码（可以抽取为公共函数的）
> 2. 超过 300 行的文件（需要拆分的）
> 3. 跨层调用的代码（违反架构约定的）
> 4. 硬编码的常量（应该放到 config.py 的）
> 给我一份重构清单，不要直接改，先列出来我审核"

---

## 五、代码层面的具体规范（实用版，不过度）

### 5.1 窗口/页面文件的标准写法

```python
# windows/main_window.py

from PySide6.QtWidgets import QMainWindow, QMessageBox
from PySide6.QtCore import Signal

from services.data_service import DataService
from workers.background_worker import BackgroundWorker
from utils.logger import get_logger

logger = get_logger(__name__)


class MainWindow(QMainWindow):
    # 主窗口: 负责 UI 展示和信号转发, 不处理业务逻辑

    # 信号定义区
    data_loaded = Signal(dict)

    def __init__(self):
        super().__init__()
        self._init_ui()
        self._connect_signals()
        self._data_service = DataService()

    def _init_ui(self):
        # 只负责创建和布局控件
        ...

    def _connect_signals(self):
        # 只负责连接信号和槽
        self.btn_load.clicked.connect(self._on_load_clicked)

    def _on_load_clicked(self):
        # 按钮点击: 启动后台任务, UI 只负责触发
        self.btn_load.setEnabled(False)
        self._worker = BackgroundWorker(self._data_service.load_data)
        self._worker.finished.connect(self._on_data_loaded)
        self._worker.error.connect(self._on_error)
        self._worker.start()

    def _on_data_loaded(self, result: dict):
        # 数据加载完成: 更新 UI 显示
        self.btn_load.setEnabled(True)
        # 更新 UI...

    def _on_error(self, error_msg: str):
        # 错误处理: 给用户友好提示
        self.btn_load.setEnabled(True)
        logger.error(f"数据加载失败: {error_msg}")
        QMessageBox.warning(self, "错误", f"操作失败: {error_msg}")
```

**要点：**
- UI 类里只有三类方法: `_init_ui`（创建控件）、`_on_xxx`（事件处理）、`_update_xxx`（更新显示）
- 事件处理方法只做"调用 service/worker"，不做具体业务
- 错误必须有 logger 记录 + 用户友好提示

---

### 5.2 Service 层的标准写法

```python
# services/data_service.py

from pathlib import Path
from typing import Optional

from models.task_model import TaskModel
from config import AppConfig
from utils.logger import get_logger

logger = get_logger(__name__)


class DataService:
    # 数据服务: 处理数据的加载、保存、转换, 不依赖任何 UI

    def load_data(self, file_path: str) -> Optional[TaskModel]:
        # 从文件加载数据, 返回 TaskModel 或 None
        path = Path(file_path)
        if not path.exists():
            logger.warning(f"文件不存在: {file_path}")
            return None
        try:
            # 实际加载逻辑...
            return TaskModel(...)
        except Exception as e:
            logger.error(f"加载数据失败: {e}", exc_info=True)
            raise  # 抛出异常, 让调用方(worker)决定怎么处理
```

**要点：**
- Service 层不 import PySide6
- Service 层的异常要么处理要么抛出，不要吞掉
- 返回值用 Model 对象，不用裸 dict（让 AI 迭代时有明确的类型约束）

---

### 5.3 Worker 层的标准写法

```python
# workers/background_worker.py

from PySide6.QtCore import QThread, Signal


class BackgroundWorker(QThread):
    # 通用后台任务执行器: 在子线程中执行传入的函数

    finished = Signal(object)  # 成功结果
    error = Signal(str)        # 错误信息
    progress = Signal(int)     # 进度 0-100

    def __init__(self, task_func, *args, **kwargs):
        super().__init__()
        self._task_func = task_func
        self._args = args
        self._kwargs = kwargs

    def run(self):
        # 子线程执行体
        try:
            result = self._task_func(*self._args, **self._kwargs)
            self.finished.emit(result)
        except Exception as e:
            self.error.emit(str(e))
```

**要点：**
- Worker 不碰 UI，只通过 Signal 通信
- 通用 Worker 可以复用，避免每个功能都写一个 QThread 子类

---

### 5.4 配置管理

```python
# config.py

from pathlib import Path
from PySide6.QtCore import QStandardPaths


class AppConfig:
    # 全局配置: 所有常量、路径的唯一来源

    APP_NAME = "MyApp"
    APP_VERSION = "1.0.0"

    # 数据目录
    DATA_DIR = Path(QStandardPaths.writableLocation(
        QStandardPaths.StandardLocation.AppDataLocation
    )) / APP_NAME
    LOG_DIR = DATA_DIR / "logs"
    CONFIG_FILE = DATA_DIR / "config.json"

    # UI 相关
    WINDOW_MIN_WIDTH = 800
    WINDOW_MIN_HEIGHT = 600
    SPLASH_DURATION_MS = 1500

    # 业务相关
    MAX_RETRY_COUNT = 3
    REQUEST_TIMEOUT = 30
```

**要点：**
- 所有魔法数字、路径、超时时间等常量都在这里
- AI 迭代时如果需要新常量，加到这里，不要散落在业务代码中

---

### 5.5 日志标准

```python
# utils/logger.py

import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
from PySide6.QtCore import QStandardPaths
from config import AppConfig


def get_logger(name: str) -> logging.Logger:
    # 获取日志器, 全局统一配置
    logger = logging.getLogger(name)
    if logger.handlers:  # 避免重复添加 handler
        return logger

    logger.setLevel(logging.DEBUG)

    # 文件日志(自动轮转)
    AppConfig.LOG_DIR.mkdir(parents=True, exist_ok=True)
    file_handler = RotatingFileHandler(
        AppConfig.LOG_DIR / "app.log",
        maxBytes=5 * 1024 * 1024,  # 5MB
        backupCount=3,
        encoding="utf-8"
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    ))

    # 控制台日志(开发用)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(logging.Formatter(
        "%(levelname)s %(name)s: %(message)s"
    ))

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    return logger
```

---

## 六、防止代码腐烂的 7 条铁律（给 AI 的明确指令）

在 CONVENTIONS.md 中明确写入以下铁律，每次让 AI 开发时提醒它遵守：

| 编号 | 铁律 | 说明 |
|------|------|------|
| 1 | **不跨界** | UI 文件不写业务逻辑，Service 文件不碰 UI 控件 |
| 2 | **不重复** | 写新功能前先检查 PROJECT_MAP.md，复用已有组件 |
| 3 | **不硬编码** | 所有常量进 config.py，所有路径用 QStandardPaths |
| 4 | **不阻塞** | 耗时操作必须进 Worker，主线程只做 UI 刷新 |
| 5 | **不吞异常** | 每个 except 必须有 logger 记录，不允许 except: pass |
| 6 | **不膨胀** | 单文件超 300 行必须拆分，单函数超 50 行必须拆分 |
| 7 | **不猜** | 不确定的设计决策，先问人类，不要自己拍板 |

---

## 七、给 AI 的 Prompt 模板（可直接复制使用）

### 7.1 开发新功能时

```
请先阅读以下两个文件：
[粘贴 PROJECT_MAP.md 内容]
[粘贴 CONVENTIONS.md 内容]

我要实现 [功能描述]。
请先给出方案（新建哪些文件、修改哪些文件、各文件职责），
不要直接写代码。
```

### 7.2 写代码时

```
方案我确认了，请开始实现。
注意：
- 遵守 CONVENTIONS.md 中的所有约定
- 完成后更新 PROJECT_MAP.md
- 如果发现需要新增常量，加到 config.py 中
```

### 7.3 修 Bug 时

```
出了一个 bug：[描述现象]
请先阅读相关文件 [文件路径]，分析根因。
先告诉我修复方案和可能的影响范围，不要直接改代码。
```

### 7.4 技术债清理时

```
请阅读以下文件，列出：
1. 重复代码（可抽取为公共函数的）
2. 违反架构分层约定的代码
3. 硬编码的常量
4. 超过 300 行的文件
给我一份清单，不要直接改。
```

---

## 八、总结

核心就三件事：

1. **【物理隔离】** -> 用目录结构强制分层，让 AI 想乱都难
2. **【全局导航】** -> 用 PROJECT_MAP.md 让 AI 始终知道"已有什么"
3. **【流程约束】** -> 先方案后代码，先审核后执行，先问后猜
